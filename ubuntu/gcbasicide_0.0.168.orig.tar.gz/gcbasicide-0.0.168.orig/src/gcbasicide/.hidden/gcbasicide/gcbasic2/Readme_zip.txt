Thank you for downloading Great Cow BASIC!

To use this version, the following must be done:

	1a. Install gputils to its default location (C:\Program Files\gputils),
	-- OR --
	1b. Install MPASM to the GCBASIC directory.

	2. Alter the included compile.bat file according to the instructions within

If you find these instructions confusing and are running MS Windows, please use the .exe installer that is also available from the GCBASIC web page. This will do these things automatically.